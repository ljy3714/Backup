package com.ryanlin.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.*;

public class MySQL {
    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.jdbc.Driver");  //加载驱动，选择桥梁的材质
            System.out.println("注册驱动成功");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("注册驱动失败");  //加载失败
        }
        String url = "jdbc:mysql://localhost:3306/estatedb";  //固定写法 端口号后面跟数据库名称
        Connection cnn = null;
        try {
            cnn = DriverManager.getConnection(url, "root", "lin");  //开始建立连接
            System.out.println("数据库链接成功");
            Statement stm = cnn.createStatement();
            ResultSet rs = stm.executeQuery("select * from owner where PersonID in(select PersonID from registration group by PersonID having count(*)>2);");  //Statement执行数据库操作语句，返回一个数组
            while (rs.next())                       //每次只能获取返回数组的一行数据
            {
                System.out.println("身份证号：" + rs.getInt(1) + " " + "姓名：" + rs.getString(2)+ " " + "性别：" + rs.getString(3)+ " "+"职业：" + rs.getString(4)+" "+"身份地址：" + rs.getString(5)+" "+"电话:" + rs.getString((6)));
            }
            rs.close();
            stm.close();   //及时关闭Statement和ResultSet对象

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("数据库链接失败");
        } finally {
            try {
                cnn.close();    //关闭连接
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}